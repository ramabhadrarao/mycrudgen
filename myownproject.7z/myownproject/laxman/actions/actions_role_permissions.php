<?php
include('../includes/session.php');
include('../includes/dbconfig.php');

$action = $_REQUEST['action'];

switch ($action) {
    case 'fetch':
        if (!check_permission('read_manage_role_permissions')) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit();
        }

        $search = $_GET['search'] ?? '';
        $sql = "SELECT * FROM role_permissions WHERE ";
        $sql .= "permission_id LIKE '%$search%'";
        $sql .= " ORDER BY role_id DESC";
        $result = $conn->query($sql);
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        $permissions = [
            'update' => check_permission('update_manage_role_permissions'),
            'delete' => check_permission('delete_manage_role_permissions')
        ];
        echo json_encode(['success' => true, 'data' => $data, 'permissions' => $permissions]);
        break;

    case 'save':
        if (!check_permission('create_manage_role_permissions') && !check_permission('update_manage_role_permissions')) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit();
        }

        $id = $_POST['role_id'] ?? '';
        $permission_id = $_POST['permission_id'];

        if ($id) {
            if (!check_permission('update_manage_role_permissions')) {
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                exit();
            }

            // Update existing record
            $sql = "UPDATE role_permissions SET ";
            $sql .= "permission_id = ?, ";
            $sql .= "updated_at = NOW() WHERE role_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('si', $permission_id, $id);
        } else {
            if (!check_permission('create_manage_role_permissions')) {
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                exit();
            }

            // Check for duplicate record
            $duplicateCheckSql = "SELECT * FROM role_permissions WHERE  = ?";
            $duplicateStmt = $conn->prepare($duplicateCheckSql);
            $duplicateStmt->bind_param('', );
            $duplicateStmt->execute();
            $duplicateResult = $duplicateStmt->get_result();
            if ($duplicateResult->num_rows > 0) {
                echo json_encode(['success' => false, 'message' => 'Record already exists']);
                exit();
            }

            // Insert new record
            $sql = "INSERT INTO role_permissions (permission_id, created_at, updated_at) VALUES (?, NOW(), NOW())";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('s', $permission_id);
        }

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => $conn->error]);
        }
        break;

    case 'get':
        if (!check_permission('read_manage_role_permissions')) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit();
        }

        $id = $_GET['id'];
        $sql = "SELECT role_permissions.role_id, roles.role_name AS role_name, role_permissions.permission_id, permissions.permission_name AS permission_name FROM role_permissions JOIN roles ON role_permissions.role_id = roles.role_id JOIN permissions ON role_permissions.permission_id = permissions.permission_id WHERE role_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        echo json_encode(['success' => true, 'data' => $data]);
        break;

    case 'delete':
        if (!check_permission('delete_manage_role_permissions')) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit();
        }

        $id = $_POST['id'];
        $sql = "DELETE FROM role_permissions WHERE role_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $id);
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => $conn->error]);
        }
        break;

    case 'search_roles':
        if (!check_permission('read_manage_role_permissions')) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit();
        }

        $search = $_GET['search'];
        $sql = "SELECT role_id AS id, role_name AS text FROM roles WHERE role_name LIKE ?";
        $stmt = $conn->prepare($sql);
        $search = "%{$search}%";
        $stmt->bind_param('s', $search);
        $stmt->execute();
        $result = $stmt->get_result();
        $items = [];
        while ($row = $result->fetch_assoc()) {
            $items[] = $row;
        }
        echo json_encode(['items' => $items]);
        break;
    case 'search_permissions':
        if (!check_permission('read_manage_role_permissions')) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit();
        }

        $search = $_GET['search'];
        $sql = "SELECT permission_id AS id, permission_name AS text FROM permissions WHERE permission_name LIKE ?";
        $stmt = $conn->prepare($sql);
        $search = "%{$search}%";
        $stmt->bind_param('s', $search);
        $stmt->execute();
        $result = $stmt->get_result();
        $items = [];
        while ($row = $result->fetch_assoc()) {
            $items[] = $row;
        }
        echo json_encode(['items' => $items]);
        break;
    case 'get_roles':
        if (!check_permission('read_manage_role_permissions')) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit();
        }

        $role_id = $_GET['id'];
        $sql = "SELECT * FROM roles WHERE role_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $role_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        echo json_encode(['success' => true, 'data' => $data]);
        break;
    case 'get_permissions':
        if (!check_permission('read_manage_role_permissions')) {
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit();
        }

        $permission_id = $_GET['id'];
        $sql = "SELECT * FROM permissions WHERE permission_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $permission_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        echo json_encode(['success' => true, 'data' => $data]);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}
?>
