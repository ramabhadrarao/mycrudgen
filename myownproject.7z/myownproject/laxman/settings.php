<?php

// Database settings

return [
    'db' => [
        'host' => 'localhost',
        'dbname' => 'laxman',
        'user' => 'ramabhadrarao',
        'password' => 'nihita1981',
    ],
];