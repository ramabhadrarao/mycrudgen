<?php

// Database settings

return [
    'db' => [
        'host' => 'localhost',
        'dbname' => 'mytestproject',
        'user' => 'ramabhadrarao',
        'password' => 'nihita1981',
    ],
];