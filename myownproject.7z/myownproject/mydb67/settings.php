<?php

// Database settings

return [
    'db' => [
        'host' => 'localhost',
        'dbname' => 'your_database_name',
        'user' => 'your_database_user',
        'password' => 'your_database_password',
    ],
];