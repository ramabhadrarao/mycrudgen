<?php

// Database settings

return [
    'db' => [
        'host' => 'localhost',
        'dbname' => 'mydb25',
        'user' => 'root',
        'password' => '',
    ],
];