<?php
include('../includes/header.php');
?>

<div class="container mx-auto mt-8">
<h1 class="text-xl mb-6 text-gray-800 bg-gray-200 font-bold border-b border-dashed border-gray-400 px-4 py-2 rounded-lg">Dashboard</h1>
  
    
    <?php
    if (isset($_GET['page'])) {
        $page = $_GET['page'];
        switch ($page) {
            case 'change_password':
                include('change_password.php');
                break;
           
            default:
                echo "<p>Page not found.</p>";
        }
    } else {
        include('../includes/usermenu.php'); 
    }
    ?>
</div>

<?php include('../includes/footer.php'); ?>
</body>
</html>