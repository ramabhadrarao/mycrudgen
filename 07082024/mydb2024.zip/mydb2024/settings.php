<?php

// Database settings

return [
    'db' => [
        'host' => 'localhost',
        'dbname' => 'mydb202408',
        'user' => 'root',
        'password' => '',
    ],
];